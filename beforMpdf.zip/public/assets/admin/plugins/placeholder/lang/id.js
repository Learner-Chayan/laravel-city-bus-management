/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","id",{title:"Properti isian sementara",toolbar:"Buat isian sementara",name:"Nama Isian Sementara",invalidName:"Isian sementara tidak boleh kosong dan tidak boleh mengandung karakter berikut: [, ], \x3c, \x3e",pathName:"isian sementara"});